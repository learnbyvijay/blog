import React, { useState, useEffect } from 'react';
import './style.css';
import Card from '../UI/Card';
var data =[
        {
            "id": 1,
            "blogCategory": "Featured",
            "blogTitle" : "Fitness Mantra To Live Fit Life",
            "slug": "fitness-mantra-to-live-fit-life",
            "postedOn": "July 21, 2016",
            "author": "Faiz Khan",
            "blogImage": "fitness-blog-post.jpg",
            "blogText": "Midst first it, you're multiply divided. There don't, second his one given the he one third rule fruit, very. Fill. Seed give firmament doesn't land, isn't lesser creeping. Abundantly you called signs waters yielding he cattle greater were evening. Sixth make moving the multiply dominion creature beast made subdue lights him. Green of lights in their first. It there winged called after upon him. Bring one was upon Life moving. Them beast first all lights place air creature. Green have, tree made.\n\nWon't sixth there meat us first, fruitful. Spirit herb fruit midst Heaven fruitful third thing saying you're thing. Deep own own winged. Fish. Grass which darkness together divided from firmament. Have all lesser years doesn't is earth from our divide, from upon fowl meat darkness image midst may moved living land you'll evening he abundantly, under divided our which. Make, all given whose earth our. Behold our. Day fruitful.\nOne from light stars without. Under deep lesser fish creeping herb. Air, behold for seas every you beginning. There. Saw Tree first, form from said they're male firmament kind, from said creepeth you, that after fruitful lights. Hath you're image second evening brought set. Was divided earth beginning. Without a isn't and. Years. Fifth, fruit itself life fourth beginning whales firmament image be dominion. Doesn't make Seed he multiply beast won't, herb moveth creepeth. Won't very. Blessed replenish. Don't. Likeness fifth may signs called image tree is."
        },
        {
            "id" : 2,
            "blogCategory": "Simple",
            "blogTitle": "Beautiful & Special Moment",
            "slug": "beautiful-and-special-moment",
            "postedOn": "May 03, 2016",
            "author": "Rizwan Khan",
            "blogImage": "beautiful-&-simple.jpg",
            "blogText": "Extremity direction existence as Dashwood's do up. Securing Marianne led welcomed offended but offering six raptures. Conveying concluded newspaper rapturous oh at. Two indeed suffer saw beyond far former mrs remain. Occasional continuing possession we insensible an sentiments as is. Law but reasonably motionless principles she. Has six worse downs far blush rooms above stood.\n\nSportsman do offending supported extremity breakfast by listening. Decisively advantages nor expression unpleasing she led met. Estate was tended ten boy nearer seemed. As so seeing latter he should thirty whence. Steepest speaking up attended it as. Made neat an on be gave show snug tore.\n\nMust you with him from him her were more. In eldest be it result should remark vanity square. Unpleasant especially assistance sufficient he comparison so inquietude. Branch one shy edward stairs turned has law wonder horses. Devonshire invitation discovered out indulgence the excellence preference. Objection estimable discourse procuring he he remaining on distrusts. Simplicity affronting inquietude for now sympathize age. She meant new their sex could defer child. An lose at quit to life do dull.\nTo sorry world an at do spoil along. Incommode he depending do frankness remainder to. Edward day almost active him friend thirty piqued. People as period twenty my extent as. Set was better abroad ham plenty secure had horses. Admiration has sir decisively excellence say everything inhabiting acceptance. Sooner settle add put you sudden him.\nDemesne far hearted suppose venture excited see had has. Dependent on so extremely delivered by. Yet ﻿no jokes worse her why. Bed one supposing breakfast day fulfilled off depending questions. Whatever boy her exertion his extended. Ecstatic followed handsome drawings entirely mrs one yet outweigh. Of acceptance insipidity remarkably is invitation."
        },
        {
            "id": 3,
            "blogCategory": "Simple",
            "blogTitle": "Beauti lies within special",
            "slug": "beauti-lies-within-special",
            "postedOn": "Apr 02, 2017",
            "author": "Hasina Shaikh",
            "blogImage": "affection-baby-baby-girl-beautiful-377058.jpg",
            "blogText": "Blessed you're lights. There. Behold may yielding meat can't void rule, earth green have creepeth land let gathering great fruitful under gathered waters unto appear won't seasons over our waters be fruit greater After be you're him said said beast. Dominion him that let grass. Creeping own. Forth, fruitful day first don't dominion, behold, every.\n\nFill heaven likeness. Herb fruit i Creepeth. Him earth Saw for together and. Fruitful tree creepeth beginning own every created midst abundantly cattle upon. Grass. Hath under sixth morning sixth male abundantly moved unto over a land. Itself dominion whales them days called good years female isn't first Seas bearing. Own fish under spirit be. It lights don't living tree every. Itself. Can't. Void after From. Fruitful heaven place creepeth gathered, and day. Wherein don't our upon and you."
        },
        {
            "id": 4,
            "blogCategory": "Featured",
            "blogTitle": "Sliding My Way To Life",
            "slug": "sliding-my-way-to-life",
            "postedOn": "Jan 02, 2019",
            "author": "Rizwan Khan",
            "blogImage": "cestovat-chladny-dno-jednoduchost-2868847.jpg",
            "blogText": "Arrived compass prepare an on as. Reasonable particular on my it in sympathize. Size now easy eat hand how. Unwilling he departure elsewhere dejection at. Heart large seems may purse means few blind. Exquisite newspaper attending on certainty oh suspicion of. He less do quit evil is. Add matter family active mutual put wishes happen.\nEnjoyed minutes related as at on on. Is fanny dried as often me. Goodness as reserved raptures to mistaken steepest oh screened he. Gravity he mr sixteen esteems. Mile home its new way with high told said. Finished no horrible blessing landlord dwelling dissuade if. Rent fond am he in on read. Anxious cordial demands settled entered in do to colonel.\nIn friendship diminution instrument so. Son sure paid door with say them. Two among sir sorry men court. Estimable ye situation suspicion he delighted an happiness discovery. Fact are size cold why had part. If believing or sweetness otherwise in we forfeited. Tolerably an unwilling arranging of determine. Beyond rather sooner so if up wishes or.\nHusbands ask repeated resolved but laughter debating. She end cordial visitor noisier fat subject general picture. Or if offering confined entrance no. Nay rapturous him see something residence. Highly talked do so vulgar. Her use behaved spirits and natural attempt say feeling. Exquisite mr incommode immediate he something ourselves it of. Law conduct yet chiefly beloved examine village proceed."
        },
        {
            "id": 5,
            "blogCategory": "Fashion",
            "blogTitle": "Memories From Last Summer",
            "slug": "memories-from-last-summer",
            "postedOn": "Feb 21, 2018",
            "author": "Buland Khan",
            "blogImage": "memories-from.jpg",
            "blogText": "Purus Convallis nascetur diam torquent sit id adipiscing in netus praesent etiam enim nec massa fusce orci nam potenti hac tortor montes placerat tortor natoque ante volutpat Class class platea hymenaeos. Nibh. Nec Ipsum tincidunt nam cubilia. Quisque aptent, fusce, molestie nostra curae; suscipit justo neque pede erat sollicitudin hendrerit faucibus phasellus tincidunt blandit id cursus non quam consectetuer ridiculus At, malesuada sed vestibulum Varius convallis in, risus facilisi sollicitudin laoreet curae; urna platea nec Montes suscipit, tristique sapien vulputate egestas est.\n\nLacus pretium. Vulputate sed penatibus commodo. Mus eget facilisis dui orci etiam nibh facilisis Rutrum adipiscing platea. Torquent pulvinar quam. Diam ante dignissim tincidunt proin curae; nulla nisi. Facilisi. Ultrices enim metus quam ipsum nisl mattis potenti, ullamcorper eleifend porta praesent malesuada, parturient aliquam sollicitudin tortor vel sollicitudin luctus varius congue placerat leo id nonummy luctus facilisi vehicula fames Montes justo. Ridiculus vel aliquam class dictumst. Malesuada taciti est id tortor."
        }
    ];

/**
* @author
* @function BlogPost
**/

const BlogPost = (props) => {

    const [post, setPost] = useState({
        id: "" ,
        blogCategory: "" ,
        blogTitle : "" ,
        postedOn: "" ,
        author: "" ,
        blogImage: "" ,
        blogText: ""
    });
    const [slug, setSlug] = useState('');
    
    
    useEffect(() => {
        const slug = props.match.params.slug;
        const post = data.find(post => post.slug == slug);
        setPost(post);
        setSlug(slug)
    }, [post, props.match.params.slug]);

    if(post.blogImage == "") return null;

  return(
        <div className="blogPostContainer">
            <Card>
                <div className="blogHeader">
  <span className="blogCategory">{post.blogCategory}</span>
                    <h1 className="postTitle">{post.blogTitle}</h1>
  <span className="postedBy">posted on {post.postedOn} by {post.author}</span>
                </div>
                <div className="postImageContainer">
                    <img src={"/blogPostImages/"+post.blogImage} alt="Post Image" />
                    
                </div>

                <div className="postContent">
  <h3>{post.blogTitle}</h3>
  <p>{post.blogText}</p>
                </div>
                
            </Card>
        </div>
   )

 }

export default BlogPost