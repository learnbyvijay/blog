import React from 'react'

/**
* @author
* @function ContactUS
**/

const ContactUS = (props) => {
  return(
    <div className="form" >
    	<form>
    	<label for="EMAIL ID">Name</label><br/>
        <input type="text" name="Email id" id="Email id" /><br/>
        <label for="EMAIL ID">Email Id:</label><br/>
        <input type="text" name="Email id" id="Email id" /><br/>
        <input type="submit" name="Email id" id="Email id" />
        </form>


    </div>
   )

 }

export default ContactUS